<template>
  <div class="focusingWrap">
    <p class="title">
      <span>icon</span>聚焦
    </p>
    <ul>
      <li>
        <img src="/static/image/bg-62.jpg" alt>
      </li>
      <li>
        <img src="/static/image/bg-62.jpg" alt>
      </li>
      <li>
        <img src="/static/image/bg-62.jpg" alt>
      </li>
    </ul>
  </div>
</template>

<script>
export default {};
</script>

<style scoped lang='scss'>
@import './index.scss';
</style>