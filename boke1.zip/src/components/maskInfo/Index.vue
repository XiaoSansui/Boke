<template>
  <div class="maskInfo">
    <div class="avatar">
      <img src="/static/image/bg-53.jpg" alt="avatar">
    </div>
    <div class="motto">
      <p>23333</p>
    </div>
    <ul class="contact">
      <li>
        <span></span>
      </li>
      <li>
        <span></span>
      </li>
      <li>
        <span></span>
      </li>
    </ul>
  </div>
</template>

<script>
export default {};
</script>

<style scoped lang='scss'>
@import './index.scss';
</style>