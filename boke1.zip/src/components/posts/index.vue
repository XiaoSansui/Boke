<template>
  <div>
    <p class="title">
      <span>icon</span>Posts
    </p>
    <ul class="postsWrap">
      <li>
        <div class="info">
          <p class="infoTitle">DAAqweqeqweqweqweqweweqqweqweqwSDAD</p>
          <p class="time">
            <span>icon</span>
            <span>2019-1-1</span>
            <span>icon</span>
          </p>
          <div class="infoStatus">
            <p>
              <span>icon</span>99.23k热度
            </p>
            <p>
              <span>icon</span>492评论
            </p>
            <p>
              <span>icon</span>分享
            </p>
          </div>
          <p
            class="explain"
          >2131231231123123213123123211111111111111111111111111111111111111111123111111111111111111111111111111111111111111111111111111111123123123123312312312321312312321312312321312321</p>
          <p>
            <span>icon</span>
          </p>
        </div>
        <div class="preview">
          <img src="/static/image/bg-62.jpg" alt>
        </div>
      </li>
      <li>
        <div class="info">
          <p class="infoTitle">DAAqweqeqweqweqweqweweqqweqweqwSDAD</p>
          <p class="time">
            <span>icon</span>
            <span>2019-1-1</span>
            <span>icon</span>
          </p>
          <div class="infoStatus">
            <p>
              <span>icon</span>99.23k热度
            </p>
            <p>
              <span>icon</span>492评论
            </p>
            <p>
              <span>icon</span>分享
            </p>
          </div>
          <p
            class="explain"
          >2131231231123123213123123211111111111111111111111111111111111111111123111111111111111111111111111111111111111111111111111111111123123123123312312312321312312321312312321312321</p>
          <p class="more">
            <span>icon</span>
          </p>
        </div>
        <div class="preview">
          <img src="/static/image/bg-62.jpg" alt>
        </div>
      </li>
    </ul>
    <div class="loading">
      <i class="line"></i>
      <img src="/static/image/postload.gif" alt>
      <p>qewqewqe</p>
    </div>
  </div>
</template> 

<script>
export default {};
</script>

<style scoped lang='scss'>
@import "./index.scss";
</style>