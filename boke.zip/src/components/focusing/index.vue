<template>
  <div class="focusingWrap">
    <p class="title">
      <span>icon</span>聚焦
    </p>
    <ul>
      <li>
        <img src="../../assets/bg-62.jpg" alt>
      </li>
      <li>
        <img src="../../assets/bg-62.jpg" alt>
      </li>
      <li>
        <img src="../../assets/bg-62.jpg" alt>
      </li>
    </ul>
  </div>
</template>

<script>
export default {};
</script>

<style scoped lang='scss'>
.focusingWrap {
  .title {
    font-size: 20px;
    color: #333;
    font-weight: 600;
    margin: 2em 0 1em 0;
    padding-bottom: 0.5em;
    border-bottom: 1px dashed #c9c9c9;
  }
  ul {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    li {
      width: 33%;
      img {
        width: 100%;
        height: 100%;
      }
    }
  }
}
</style>