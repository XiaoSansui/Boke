<template>
  <div>
    <p class="title">
      <span>icon</span>Posts
    </p>
    <ul class="postsWrap">
      <li>
        <div class="info">
          <p class="infoTitle">DAAqweqeqweqweqweqweweqqweqweqwSDAD</p>
          <p class="time">
            <span>icon</span>
            <span>2019-1-1</span>
            <span>icon</span>
          </p>
          <div class="infoStatus">
            <p>
              <span>icon</span>99.23k热度
            </p>
            <p>
              <span>icon</span>492评论
            </p>
            <p>
              <span>icon</span>分享
            </p>
          </div>
          <p
            class="explain"
          >2131231231123123213123123211111111111111111111111111111111111111111123111111111111111111111111111111111111111111111111111111111123123123123312312312321312312321312312321312321</p>
          <p>
            <span>icon</span>
          </p>
        </div>
        <div class="preview">
          <img src="../../assets/bg-62.jpg" alt>
        </div>
      </li>
      <li>
        <div class="info">
          <p class="infoTitle">DAAqweqeqweqweqweqweweqqweqweqwSDAD</p>
          <p class="time">
            <span>icon</span>
            <span>2019-1-1</span>
            <span>icon</span>
          </p>
          <div class="infoStatus">
            <p>
              <span>icon</span>99.23k热度
            </p>
            <p>
              <span>icon</span>492评论
            </p>
            <p>
              <span>icon</span>分享
            </p>
          </div>
          <p
            class="explain"
          >2131231231123123213123123211111111111111111111111111111111111111111123111111111111111111111111111111111111111111111111111111111123123123123312312312321312312321312312321312321</p>
          <p class="more">
            <span>icon</span>
          </p>
        </div>
        <div class="preview">
          <img src="../../assets/bg-62.jpg" alt>
        </div>
      </li>
    </ul>
    <div class="loading">
      <i class="line"></i>
      <img src="../../assets/postload.gif" alt>
      <p>qewqewqe</p>
    </div>
  </div>
</template> 

<script>
export default {};
</script>

<style scoped lang='scss'>
.title {
  font-size: 20px;
  color: #333;
  font-weight: 600;
  margin: 2em 0 1em 0;
  padding-bottom: 0.5em;
  border-bottom: 1px dashed #c9c9c9;
}
.postsWrap {
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  li {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    padding: 2em;
    border: 1px solid #c5c5c5;
    border-radius: 10px;
    margin-bottom: 1em;
    transition: box-shadow 0.3s;
    &:nth-child(even) {
      flex-direction: row-reverse;
      .preview {
        margin-left: 0;
        margin-right: 1em;
      }
    }
    &:hover {
      box-shadow: 0 0 10px rgb(128, 122, 122);
      .preview img {
        transform: scale(1.2);
      }
    }
    div {
      width: 50%;
    }
    .info {
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      .infoTitle {
        margin-bottom: 5px;
        width: 90%;
        font-size: 22px;
        color: #333;
        font-weight: 600;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .time {
        margin-bottom: 5px;
        font-size: 14px;
        color: #666;
      }
      .infoStatus {
        margin-bottom: 1em;
        width: 100%;
        font-size: 14px;
        color: #666;
        display: flex;
        flex-direction: row;
        justify-content: flex-start;
        align-items: center;
        p {
          margin-right: 1em;
        }
      }
      .explain {
        margin-bottom: 1em;
        width: 90%;
        font-size: 16px;
        color: #666;
        line-height: 1.3em;
        word-wrap: break-word;
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 3;
        -webkit-box-orient: vertical;
      }
      .more {
        width: 90%;
      }
    }
    .preview {
      width: 80%;
      overflow: hidden;
      margin-left: 1em;
      img {
        width: 100%;
        transition: 0.5s;
      }
    }
  }
}
.loading {
  display: flex;
  flex: 1;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  .line {
    width: 1px;
    height: 4em;
    margin-top: -1em;
    background: #333;
  }
}
</style>