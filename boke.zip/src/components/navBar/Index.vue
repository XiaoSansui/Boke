<template>
  <div class="navWrap">
    <div class="avatar">
      <img src="../../assets/bg-53.jpg" alt="avatar">
    </div>
    <div class="barList">
      <div>me</div>
      <div>search</div>
      <div @click="handleMenu">menu</div>
      <ul class="menuList" :class="menuStatus?'menuListShow':'menuListHide'">
        <li>视频</li>
        <li>聚焦</li>
        <li>软件</li>
        <li>文章</li>
        <li>美句</li>
        <li>创意工坊</li>
      </ul>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      menuStatus: false
    };
  },
  methods: {
    handleMenu() {
      // this.menuStatus = !this.menuStatus;
      this.$set(this, "menuStatus", !this.menuStatus);
      console.log(this.menuStatus);
    }
  }
};
</script>

<style scoped lang='scss'>
.navWrap {
  width: 100%;
  height: 60px;
  background: rgba(255, 255, 255, 0);
  position: absolute;
  top: 0;
  right: 0;
  z-index: 5;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  color: rgba(255, 255, 255, 0.548);
  transition: color, background 0.6s;
  &:hover {
    background: rgba(255, 255, 255, 0.9);
    color: rgba(0, 0, 0, 0.9);
  }
  .avatar {
    width: 45px;
    height: 45px;
    text-align: center;
    border: 1px solid #333;
    border-radius: 50%;
    overflow: hidden;
    box-shadow: 0 0 5px whitesmoke;
    margin-left: 5px;
    transition: 1s;
    img {
      width: auto;
      margin-left: -25%;
      height: 100%;
      cursor: pointer;
      transition: 1s;
    }
    &:hover {
      transform: rotate(360deg);
      img {
        transform: scale(1.5);
      }
    }
  }
  .barList {
    display: flex;
    flex-direction: row-reverse;
    justify-content: space-around;
    & > div {
      margin-right: 1em;
      cursor: pointer;
    }
    .menuList {
      margin-right: 1em;
      transform: translateX(100px) scale(0.5);
      opacity: 0;
      transition: 0.5s;
      li {
        margin-right: 1em;
        float: left;
        cursor: pointer;
      }
    }
    .menuListShow {
      transform: translateX(0) scale(1);
      opacity: 1;
    }
    .menuListHide {
      transform: translateX(100px) scale(0.5);
      opacity: 0;
    }
  }
}
</style>