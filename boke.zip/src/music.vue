<template>
  <div>
    <ul>
      <li>1</li>
      <li>2</li>
      <li>3</li>
      <li>4</li>
      <li>5</li>
      <li>1</li>
      <li>2</li>
      <li>3</li>
      <li>4</li>
      <li>5</li>
      <li>1</li>
      <li>2</li>
      <li>3</li>
      <li>4</li>
      <li>5</li>
      <li>1</li>
      <li>2</li>
      <li>3</li>
      <li>4</li>
      <li>5</li>
      <li>4</li>
      <li>5</li>
      <li>1</li>
      <li>2</li>
      <li>3</li>
      <li>4</li>
      <li>5</li>
      <li>1</li>
      <li>2</li>
      <li>3</li>
      <li>4</li>
      <li>5</li>
      <li>4</li>
      <li>5</li>
      <li>1</li>
      <li>2</li>
      <li>3</li>
      <li>4</li>
      <li>5</li>
      <li>1</li>
      <li>2</li>
      <li>3</li>
      <li>4</li>
      <li>5</li>
    </ul>
    <ul>
      <li>1</li>
      <li>2</li>
      <li>3</li>
      <li>4</li>
      <li>5</li>
      <li>1</li>
      <li>2</li>
      <li>3</li>
      <li>4</li>
      <li>5</li>
      <li>1</li>
      <li>2</li>
      <li>3</li>
      <li>4</li>
      <li>5</li>
      <li>1</li>
      <li>2</li>
      <li>3</li>
      <li>4</li>
      <li>5</li>
      <li>4</li>
      <li>5</li>
      <li>1</li>
      <li>2</li>
      <li>3</li>
      <li>4</li>
      <li>5</li>
      <li>1</li>
      <li>2</li>
      <li>3</li>
      <li>4</li>
      <li>5</li>
      <li>4</li>
      <li>5</li>
      <li>1</li>
      <li>2</li>
      <li>3</li>
      <li>4</li>
      <li>5</li>
      <li>1</li>
      <li>2</li>
      <li>3</li>
      <li>4</li>
      <li>5</li>
    </ul>
    <ul>
      <li>1</li>
      <li>2</li>
      <li>3</li>
      <li>4</li>
      <li>5</li>
      <li>1</li>
      <li>2</li>
      <li>3</li>
      <li>4</li>
      <li>5</li>
      <li>1</li>
      <li>2</li>
      <li>3</li>
      <li>4</li>
      <li>5</li>
      <li>1</li>
      <li>2</li>
      <li>3</li>
      <li>4</li>
      <li>5</li>
      <li>4</li>
      <li>5</li>
      <li>1</li>
      <li>2</li>
      <li>3</li>
      <li>4</li>
      <li>5</li>
      <li>1</li>
      <li>2</li>
      <li>3</li>
      <li>4</li>
      <li>5</li>
      <li>4</li>
      <li>5</li>
      <li>1</li>
      <li>2</li>
      <li>3</li>
      <li>4</li>
      <li>5</li>
      <li>1</li>
      <li>2</li>
      <li>3</li>
      <li>4</li>
      <li>5</li>
    </ul>
    <div class="musicPlayer">
      <div class="control" ref="control" @transitionend="$emit('controlEnd','controlEnd')">
        <!-- <i class="iconfont icon-xunhuanbofang"></i> -->
        <audio ref="music" :src="musicList[musicIndex]">您的浏览器不支持 audio 标签。</audio>
        <div class="playControl">
          <i @click="handlePrev" class="iconfont icon-shangyishou"></i>
          <i @click="handlePlay" class="iconfont" :class="playPause?'icon-zanting':'icon-bofang'"></i>
          <i @click="handleNext" class="iconfont icon-xiayishou"></i>
        </div>
        <div class="progressBar">
          <div class="progressMask" @mousedown="progressControl" ref="progressMask"></div>
          <div class="progress" ref="progress"></div>
          <span class="title">{{musicList[musicIndex]}}</span>
        </div>
        <div class="playConfig">
          <span class="time">{{musicCurrentTime}}/{{musicDuration}}</span>
          <i
            @click="handleloop"
            class="iconfont"
            :class="loop?'icon-danquxunhuan':'icon-xunhuanbofang'"
          ></i>
          <div class="sound">
            <i @click="soundControl" class="iconfont" :class="sound?'icon-jingyin':'icon-yinliang'"></i>
            <div class="volumeWrap">
              <div class="volumeMask" @mousedown="volumeControl" ref="volumeMask"></div>
              <div ref="volume" class="volume">
                <div ref="sliderBar" class="sliderBar"></div>
                <div ref="slider" class="slider"></div>
              </div>
            </div>
          </div>
          <i @click="handleList" class="iconfont icon-liebiao"></i>
          <div class="telescopic">
            <div class="top" ref="top" @click="handleComplete">
              <i class="iconfont icon-jiantou_shang"></i>
            </div>
            <div class="open" @click="handleOpen">
              <i class="iconfont icon-jiantou_zuo" v-if="showControl"></i>
              <i class="iconfont icon-jiantou_you" v-else></i>
            </div>
          </div>
        </div>
      </div>
      <div class="complete" ref="complete" @transitionend="$emit('completeEnd','completeEnd')">
        <div class="header">
          <span>Music</span>
          <i class="iconfont icon-jiantou_xia" @click="handleList"></i>
        </div>
        <div class="content">
          <div class="songSheet">
            <ul>
              <li>1</li>
              <li>2</li>
              <li>3</li>
              <li>4</li>
              <li>5</li>
              <li>1</li>
              <li>2</li>
              <li>3</li>
              <li>4</li>
              <li>5</li>
              <li>1</li>
              <li>2</li>
              <li>3</li>
              <li>4</li>
              <li>5</li>
              <li>1</li>
              <li>2</li>
              <li>3</li>
              <li>4</li>
              <li>5</li>
              <li>4</li>
              <li>5</li>
              <li>1</li>
              <li>2</li>
              <li>3</li>
              <li>4</li>
              <li>5</li>
              <li>1</li>
              <li>2</li>
              <li>3</li>
              <li>4</li>
              <li>5</li>
              <li>4</li>
              <li>5</li>
              <li>1</li>
              <li>2</li>
              <li>3</li>
              <li>4</li>
              <li>5</li>
              <li>1</li>
              <li>2</li>
              <li>3</li>
              <li>4</li>
              <li>5</li>
            </ul>
          </div>
          <div class="lyric">
            <div class="scroll">
              <ul>
                <li>1</li>
                <li>2</li>
                <li>3</li>
                <li>4</li>
                <li>5</li>
                <li>1</li>
                <li>2</li>
                <li>3</li>
                <li>4</li>
                <li>5</li>
                <li>1</li>
                <li>2</li>
                <li>3</li>
                <li>4</li>
                <li>5</li>
                <li>1</li>
                <li>2</li>
                <li>3</li>
                <li>4</li>
                <li>5</li>
                <li>4</li>
                <li>5</li>
                <li>1</li>
                <li>2</li>
                <li>3</li>
                <li>4</li>
                <li>5</li>
                <li>1</li>
                <li>2</li>
                <li>3</li>
                <li>4</li>
                <li>5</li>
                <li>4</li>
                <li>5</li>
                <li>1</li>
                <li>2</li>
                <li>3</li>
                <li>4</li>
                <li>5</li>
                <li>1</li>
                <li>2</li>
                <li>3</li>
                <li>4</li>
                <li>5</li>
              </ul>
            </div>
          </div>
          <div class="cover" @click="showCover">
            <div class="innerWrap" ref="coverWrap">
              <img ref="coverImg"
                src="https://p3.music.126.net/5RzaEbrKYSwYg7eu_5orKg==/109951163312444084.jpg?param=300y300"
              >
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { setInterval, clearInterval, setTimeout, clearTimeout } from "timers";
export default {
  data() {
    return {
      music: null, //音乐播放器
      musicList: [
        //歌曲列表
        "../static/可乐.mp3",
        "../static/岁月神偷.mp3",
        "../static/飞云之下.mp3"
      ],
      musicIndex: 0, //当前播放歌曲下标
      playPause: false, //播放暂停按钮状态
      musicLine: 0, //初始化当前音乐长度
      musicDuration: "00:00", // 音乐时间长度
      musicCurrentTime: "00:00", //已播放长度
      loop: false, //循环播放按钮
      sound: false, //音量按钮
      dragging: false, //音频是否加载完成
      move1: {
        //播放进度条 move事件参数
        dragging: false, //是否开启拖拽
        itemMask: null, //操作元素的遮罩层
        item: null, //需要改变的元素
        itemMaskWidth: null, //操作元素的width
        offsetX: null, //偏移量
        count: null, //进度比例
        num: null //进度百分比
      },
      move2: {
        //音乐调节进度条 move事件参数
        dragging: false, //是否开启拖拽
        itemMask: null, //操作元素的遮罩层
        item1: null, //需要改变的元素
        item2: null, //需要改变的元素
        itemMaskWidth: null, //操作元素的width
        offsetX: null, //偏移量
        count: null, //进度比例
        num: null //进度百分比
      },
      time1: null,
      time2: null,
      time3: null,
      showControl: false, //是否显示控制台
      showList: false, //是否显示菜单列表
      showComplete: false //是否完整音乐播放器
    };
  },
  methods: {
    //上一首
    handlePrev() {
      this.totalTime();
      //切换上一首 如果为第一首 则切换到最后一首歌。
      if (this.musicIndex > 0) {
        this.musicIndex = this.musicIndex - 1;
      } else {
        this.musicIndex = this.musicList.length - 1;
      }
      this.$refs.progress.style = `width:0;`;
      this.music.autoplay = true;
      console.log(this.musicList[this.musicIndex]);
      this.time3 = setTimeout(() => {
        if (this.music.readyState === 4) {
          this.dragging = true;
          this.playPause = true;
          this.musicLine = this.music.duration || 0;
          this.totalTime();
        } else {
          this.dragging = false;
        }
      }, 500);
    },
    //下一首
    handleNext() {
      //切换下一首 如果为最后一首 则切换到第一首歌。
      if (this.musicIndex < this.musicList.length - 1) {
        this.musicIndex = this.musicIndex + 1;
      } else {
        this.musicIndex = 0;
      }
      this.$refs.progress.style = `width:0;`;
      this.music.autoplay = true;
      console.log(this.musicList[this.musicIndex]);
      this.time3 = setTimeout(() => {
        if (this.music.readyState === 4) {
          this.dragging = true;
          this.playPause = true;
          this.musicLine = this.music.duration || 0;
          this.totalTime();
        } else {
          this.dragging = false;
        }
      }, 500);
    },
    //播放暂停
    handlePlay() {
      this.playPause = !this.playPause;
      this.dragging = true;

      if (this.playPause) {
        this.music.play();
      } else {
        this.music.pause();
      }
      this.musicLine = this.music.duration || 0;
      this.totalTime();
    },
    //循环控制
    handleloop() {
      this.loop = !this.loop;
      if (this.loop) {
        this.music.loop = true;
      } else {
        this.music.loop = false;
      }
    },

    //进度条控制
    progressControl() {
      this.move1.itemMask = this.$refs.progressMask;
      this.move1.item = this.$refs.progress;
      //鼠标按下的动作
      this.move1.itemMask.onmousedown = this.progressDown;
      //鼠标移动的动作
      this.move1.itemMask.onmousemove = this.progressMove;
      //鼠标抬起的动作
      window.onmouseup = this.progressUp;
    },
    progressDown(e) {
      this.move1.dragging = true;
      this.move1.itemMaskWidth = e.target.offsetWidth;
      this.move1.offsetX = e.offsetX;
      this.move1.count =
        1 -
        (this.move1.itemMaskWidth - this.move1.offsetX) /
          this.move1.itemMaskWidth; //获取比例
      this.move1.num = this.move1.count * 100;
      //点击时同步播放进度条位置  保存当前的进度比例
      this.move1.item.style = `width:${
        this.move1.num
      }%;transition: width 0.2s;`;
      //音频加载完成才设置音乐播放位置
      if (this.dragging) {
        this.music.currentTime = this.musicLine * this.move1.count;
      }
      //如果播放到100 如果不是单曲循环 则播放下一首
      if (this.move1.num >= 100 && !this.loop) {
        this.handleNext();
      }
    },
    progressMove(e) {
      if (this.move1.dragging) {
        this.move1.offsetX = e.offsetX;
        this.move1.count =
          1 -
          (this.move1.itemMaskWidth - this.move1.offsetX) /
            this.move1.itemMaskWidth; //获取比例
        this.move1.num = this.move1.count * 100;
        this.move1.item.style = `width:${this.move1.num}%;transition: 0;`;
      }
    },
    progressUp(e) {
      //关闭拖拽 卸载move事件  将播放进度跳转到move的最后一次位置
      this.move1.dragging = false;
      this.move1.itemMask.onmousemove = null;
      this.move1.itemMask = null;
      window.onmouseup = null;

      //音频加载完成才设置音乐播放位置
      if (this.dragging) {
        this.music.currentTime = this.musicLine * this.move1.count;
      }
    },
    //声音控制
    soundControl() {
      //设置或返回是否关闭声音。
      this.sound = !this.sound;
      if (this.sound) {
        this.music.muted = true;
      } else {
        this.music.muted = false;
      }
      //设置或返回音频的音量。
      console.log("当前音量：", this.music.volume);
    },
    volumeControl(e) {
      this.move2.itemMask = this.$refs.volumeMask;
      this.move2.item1 = this.$refs.sliderBar;
      this.move2.item2 = this.$refs.slider;
      this.music.volume = 1; //默认满音量
      //鼠标按下的动作
      this.move2.itemMask.onmousedown = this.volumeDown;
      //鼠标移动的动作
      this.move2.itemMask.onmousemove = this.volumeMove;
      //鼠标抬起的动作
      window.onmouseup = this.volumeUp;
    },
    volumeDown(e) {
      this.move2.dragging = true;
      this.move2.itemMaskWidth = e.target.offsetWidth;
      this.move2.offsetX = e.offsetX;
      this.move2.count =
        1 -
        (this.move2.itemMaskWidth - this.move2.offsetX) /
          this.move2.itemMaskWidth; //获取比例
      this.move2.num = this.move2.count * 100;

      this.music.volume = this.move2.num / 100; //设置音量
      this.move2.item1.style = `width:${this.move2.num}%;`;
      this.move2.item2.style = `left:calc(${this.move2.num}% - 6px)`;
      //如果音量小于5 变成静音状态
      if (this.move2.num < 5) {
        this.sound = true;
        this.music.muted = true;
      } else {
        this.sound = false;
        this.music.muted = false;
      }
    },
    volumeMove(e) {
      if (this.move2.dragging) {
        this.move2.offsetX = e.offsetX;
        this.move2.count =
          1 -
          (this.move2.itemMaskWidth - this.move2.offsetX) /
            this.move2.itemMaskWidth; //获取比例
        this.move2.num = this.move2.count * 100;
        this.move2.item1.style = `width:${this.move2.num}%;`;
        this.move2.item2.style = `left:calc(${this.move2.num}% - 6px)`;
        this.music.volume = this.move2.count; //设置音量
        //如果音量小于5 变成静音状态
        if (this.move2.num < 5) {
          this.sound = true;
          this.music.muted = true;
        } else {
          this.sound = false;
          this.music.muted = false;
        }
      }
    },
    volumeUp(e) {
      //关闭拖拽 卸载move事件
      this.move2.dragging = false;
      this.move2.itemMask.onmousemove = null;
      this.move2.itemMask = null;
      window.onmouseup = null;
    },
    //播放时间
    totalTime() {
      clearInterval(this.time1);
      //返回音频的长度。
      let duration = this.musicLine;
      let obj = this.countTime(duration);
      this.musicDuration = `${obj["m"]}:${obj["s"]}`;
      this.time1 = setInterval(() => {
        let currentTime = this.music.currentTime || 0;
        let count = 1 - (this.musicLine - currentTime) / this.musicLine;
        this.$refs.progress.style = `width:${count * 100}%;`;
        if (count * 100 >= 100 && !this.loop) {
          this.handleNext();
        } else if (count * 100 >= 100 && this.loop) {
          this.music.load();
        }
        //设置或返回音频中的当前播放位置。
        duration = this.music.currentTime || 0;
        obj = this.countTime(duration);
        this.musicCurrentTime = `${obj["m"]}:${obj["s"]}`;
      }, 500);
    },
    countTime(duration) {
      let m = Math.floor(duration / 60);
      let s = Math.floor(((duration / 60) % 1) * 60);
      m = m < 0 ? "00" : m < 10 ? "0" + m : m + "";
      s = s < 0 ? "00" : s < 10 ? "0" + s : s + "";
      return { m, s };
    },
    //控制台transitionend结束事件
    controlEnd() {
      if (this.showControl && (this.showList || this.showComplete)) {
        this.$refs.complete.style = "bottom: 51px;";
      } else if (this.showControl) {
        this.$refs.top.style = "top:0;";
      } else {
        this.$refs.top.style = "top:-26px;";
      }
    },
    //完整音乐播放器transitionend结束事件
    completeEnd() {
      if (!this.showControl && !this.showList && !this.showComplete) {
        this.$refs.control.style =
          "transform: translateX(-100vw) translateX(30px);";
      }
    },
    //更改控制台显示状态
    handleOpen() {
      this.showControl = !this.showControl;
      if (!this.showControl && (this.showList || this.showComplete)) {
        this.$refs.complete.style = "bottom: -320px;";
        this.showList = false;
        this.showComplete = false;
      } else if (this.showControl) {
        this.$refs.control.style = "transform: translateX(0);";
      } else {
        this.$refs.control.style =
          "transform: translateX(-100vw) translateX(30px);";
      }
    },
    //列表控制
    handleList() {
      this.showList = !this.showList;
      // this.showComplete = !this.showComplete;
      if (this.showList) {
        this.$refs.complete.style = "bottom: 51px;";
      } else {
        this.$refs.complete.style = "bottom: -320px;";
      }
    },
    //显示完整音乐播放器
    handleComplete() {
      this.showList = !this.showList;
      this.showComplete = !this.showComplete;
      this.showControl = !this.showControl;
      console.log(this.showControl, this.showList, this.showComplete);
      if (this.showControl && this.showList && this.showComplete) {
        this.$refs.control.style = "transform: translateX(0);";
        this.$refs.top.style = "top:0;";
      } else {
        this.$refs.complete.style = "bottom: -320px;";
        this.showList = false;
        this.showComplete = false;
      }
    },
    showCover(){
      this.$refs.coverWrap.style = "border-radius:50%";
      this.$refs.coverImg.style = "border-radius:50%;width:200px;height:200px;";
    }
  },
  mounted() {
    this.music = this.$refs.music;
    this.$nextTick(() => {
      //优化音频加载
      this.time2 = setTimeout(() => {
        if (this.music.readyState === 4) {
          this.musicLine = this.music.duration;
          this.dragging = true;
          this.totalTime();
        }
      }, 500);
    });
    this.progressControl();
    this.volumeControl();
    //转发transitionend事件
    this.$on("controlEnd", msg => {
      this.controlEnd();
    });
    this.$on("completeEnd", msg => {
      this.completeEnd();
    });
  },
  destroyed() {
    clearInterval(this.time1);
    clearTimeout(this.time2);
    clearTimeout(this.time3);
  }
};
</script>

<style lang="scss" scoped>
.musicPlayer {
  position: fixed;
  right: 0;
  bottom: 0;
  transform: translate3d(0);
  -webkit-touch-callout: none; /* iOS Safari */
  -webkit-user-select: none; /* Chrome/Safari/Opera */
  -khtml-user-select: none; /* Konqueror */
  -moz-user-select: none; /* Firefox */
  -ms-user-select: none; /* Internet Explorer/Edge */
  user-select: none; /* Non-prefixed version, currently not supported by any browser */
  .control {
    height: 50px;
    width: 100vw;
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: #333;
    color: white;
    transform: translateX(-100vw) translateX(30px);
    transition: transform 0.4s;
    border-top: 1px solid #111;
    position: relative;
    z-index: 99;

    .playControl {
      width: 150px;
      height: 100%;
      margin: 0 10px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      i {
        font-size: 25px;
        cursor: pointer;
      }
    }
    .progressBar {
      flex: 1;
      height: 100%;
      background-color: #444;
      text-align: center;
      position: relative;
      margin-right: 10px;
      overflow-x: hidden;
      cursor: pointer;
      .progressMask {
        width: 100%;
        height: 100%;
        position: absolute;
        top: 0;
        left: 0;
        z-index: 5;
        opacity: 0;
      }
      .progress {
        width: 0;
        height: 100%;
        background-color: #555;
        position: absolute;
        top: 0;
        left: 0;
      }
      .title {
        position: absolute;
        font-size: 18px;
        top: calc(50% - 9px);
        right: calc(50% - 9px);
      }
    }
    .playConfig {
      width: 300px;
      height: 100%;
      display: flex;
      justify-content: space-between;
      align-items: center;
      i {
        font-size: 20px;
        cursor: pointer;
      }
      .time {
        width: 90px;
      }
      .sound {
        width: 100px;
        height: 100%;
        display: flex;
        justify-content: flex-start;
        align-items: center;
        .volumeWrap {
          margin-left: 5px;
          height: 100%;
          width: 100%;
          display: flex;
          justify-content: flex-start;
          align-items: center;
          position: relative;
          cursor: pointer;
          .volumeMask {
            height: 100%;
            width: 100%;
            position: absolute;
            z-index: 5;
            opacity: 0;
          }
          .volume {
            width: 75px;
            height: 4px;
            background-color: #666;
            border-radius: 5px;
            position: relative;
          }
          .sliderBar {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            transition: width 0.1s;
            background-color: #f0f0f0;
          }
          .slider {
            position: absolute;
            top: -5px;
            left: calc(100% - 6px);
            width: 13px;
            height: 13px;
            border-radius: 50%;
            transition: left 0.1s;
            background-color: #fff;
          }
        }
      }
      .telescopic {
        width: 30px;
        height: 50px;
        position: relative;
        .top {
          width: 30px;
          height: 25px;
          display: flex;
          justify-content: center;
          align-items: center;
          position: absolute;
          top: -26px;
          left: 0;
          z-index: 1;
          background-color: #222;
          cursor: pointer;
          border-bottom: 1px solid #666;
          transition: top 0.2s;
        }
        .open {
          width: 30px;
          height: 50px;
          display: flex;
          justify-content: center;
          align-items: center;
          position: absolute;
          top: 0;
          left: 0;
          z-index: 2;
          background-color: #222;
          cursor: pointer;
        }
      }
    }
  }
  .complete {
    width: 100%;
    height: 320px;
    position: absolute;
    bottom: -320px;
    left: 0;
    z-index: 100;
    background: #333;
    color: #fff;
    transition: bottom 0.5s;
    i {
      font-size: 22px;
      cursor: pointer;
    }
    .header {
      height: 39px;
      border-bottom: 1px solid #000;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 10px;
      font-size: 16px;
    }
    .content {
      width: 100%;
      height: calc(100% - 40px);
      display: flex;
      justify-content: space-between;
      font-size: 15px;
      line-height: 20px;
      .songSheet {
        width: 280px;
        height: 100%;
        overflow: auto;
        padding: 0 10px;
        border-right: 1px solid #000;
        ul {
          margin: 5px;
        }
      }
      .lyric {
        flex: 1;
        display: flex;
        flex-direction: column;
        justify-content: flex-start;
        align-items: center;
        padding: 50px 0;
        .scroll {
          height: 200px;
          width: 90%;
          text-align: center;
          overflow-y: auto;
          &::-webkit-scrollbar {
            display: none;
          }
        }
      }
      .cover {
        width: 280px;
        height: 280px;
        display: flex;
        justify-content: center;
        align-items: center;
        // border: 1px solid greenyellow;
        .innerWrap {
          width: 260px;
          height: 260px;
          display: flex;
          justify-content: center;
          align-items: center;
          border: 1px solid #000;
          box-shadow: 0 0 15px #555 inset;
          transition: border-radius 2s;
          img {
            padding: 15px;
            width: 230px;
            height: 230px;
            transition: all 2s;
          }
        }
      }
    }
  }
}
</style>